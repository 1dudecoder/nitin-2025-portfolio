import React from "react";
import { motion } from "framer-motion";
import {
  Github,
  Twitter,
  Linkedin,
  Mail,
  Phone,
  ExternalLink,
  ChevronDown,
  GraduationCap,
  BookOpen,
} from "lucide-react";
import nitin from "./assets/nitin.jpg";

function App() {
  return (
    <div className="bg-blue  backdrop-blur-sm  p-10 shadow-[0_10px_20px_rgba(245,210,124,0.3)] hover:shadow-[0_10px_25px_rgba(245,210,124,0.5)] transition-all duration-300">
      {/* Hero Section */}
      <motion.header
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="container mx-auto px-4 py-20 text-center"
      >
        <motion.div
          className="relative w-40 h-40 mx-auto mb-4"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2 }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 rounded-full animate-spin-slow blur-xl opacity-50"></div>
          <motion.img
            src={nitin}
            alt="Nitin Negi"
            whileHover={{ scale: 2.4 }}
            initial={{ scale: 2.2 }}
            animate={{ scale: 2.2 }}
            className="relative w-full h-full rounded-full object-cover shadow-xl ring-2 ring-purple-400 my-4 z-0 object-fit"
          />
        </motion.div>
        <motion.h1
          className="pt-24 py-2 text-5xl font-bold mb-4 bg-gradient-to-r from-pink-400 via-purple-400 to-indigo-400 text-transparent bg-clip-text"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          Nitin Negi
        </motion.h1>

        <motion.p
          className="text-2xl text-purple-300 mb-4 italic"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
        >
          "Turning Ideas into Reality, One Line of Code at a Time!"
        </motion.p>

        <motion.p
          className="text-xl text-purple-200"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
        >
          Creative Full Stack Developer
        </motion.p>
        <motion.p
          className="text-xl text-purple-200 my-2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
        >
          Contact - 9634470622
        </motion.p>
        <motion.p
          className="text-xl text-purple-200 mb-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
        >
          Email - nitin7negi@gmail.com
        </motion.p>

        <motion.div
          className="flex justify-center space-x-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
        >
          {[
            { icon: Mail, href: "mailto:nitin7negi@gmail.com" },
            { icon: Github, href: "https://github.com/1dudecoder" },
            { icon: Twitter, href: "https://twitter.com/santy_nitin" },
            {
              icon: Linkedin,
              href: "https://www.linkedin.com/in/nitin-negi-b17681137/",
            },
            { icon: Phone, href: "tel:+919634470622" },
          ].map((item, index) => (
            <motion.a
              key={index}
              href={item.href}
              target={item.href.startsWith("http") ? "_blank" : undefined}
              rel={
                item.href.startsWith("http") ? "noopener noreferrer" : undefined
              }
              className="hover:text-pink-400 transition-all transform hover:scale-110"
              whileHover={{ y: -3 }}
            >
              <item.icon size={24} />
            </motion.a>
          ))}
        </motion.div>
        <motion.div
          className="mt-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
        >
          <ChevronDown
            className="mx-auto animate-bounce text-purple-400"
            size={32}
          />
        </motion.div>
      </motion.header>

      {/* Education Section */}
      <section className="container mx-auto px-4 py-16">
        <motion.h2
          className="text-3xl font-bold mb-12 text-center flex items-center justify-center gap-2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          <GraduationCap className="text-pink-400" />
          <span className="text-3xl font-bold text-center bg-gradient-to-r from-pink-400 to-purple-400 text-transparent bg-clip-text">
            Education
          </span>
        </motion.h2>
        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              institution: "Uttaranchal University",
              degree: "Master of Computer Applications (MCA)",
              period: "Completed Aug 2021",
              location: "Dehradun, Uttarakhand",
              grade: "CGPA: 7.9",
              description:
                "Gained a solid foundation in software development and problem-solving skills.",
            },
            {
              institution: "HNBGU University",
              degree: "Bachelor of Science in Information Technology",
              period: "Completed Aug 2019",
              location: "Srinagar, Uttarakhand",
              grade: "CGPA: 6.7",
              description:
                "Developed critical thinking and analytical skills through various projects.",
            },
            {
              institution: "VNIC Intercollege",
              degree: "Intermediate & High School",
              period: "2014 - 2016",
              location: "Kotdwara, Uttarakhand",
              description:
                "Focused on foundational subjects that paved the way for my tech journey.",
            },
          ].map((edu, index) => (
            <motion.div
              key={index}
              className="bg-gradient-to-br from-gray-900 to-gray-800 p-6 rounded-lg shadow-xl border border-purple-900/30 backdrop-blur-sm hover:border-purple-500/50 transition-all"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
              whileHover={{ scale: 1.02 }}
            >
              <BookOpen className="text-pink-400 mb-4" size={24} />
              <h3 className="text-xl font-bold mb-2 text-purple-200">
                {edu.institution}
              </h3>
              <p className="text-purple-300 mb-2">{edu.degree}</p>
              <p className="text-sm text-purple-400">{edu.period}</p>
              <p className="text-sm text-purple-400">{edu.location}</p>
              <p className="text-sm text-purple-300 mb-2">{edu.description}</p>
              {edu.grade && (
                <p className="text-sm text-pink-400 mt-2">{edu.grade}</p>
              )}
            </motion.div>
          ))}
        </div>
      </section>

      {/* Experience Section */}
      <section className="container mx-auto px-4 py-16">
        <motion.h2
          className="text-3xl font-bold mb-12 text-center bg-gradient-to-r from-pink-400 to-purple-400 text-transparent bg-clip-text"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          Professional Experience
        </motion.h2>
        <div className="grid md:grid-cols-2 gap-8">
          {[
            {
              company: "Prosperity Travels",
              role: "Front-end Engineer",
              period: "Aug 2024 - Present",
              location: "Dehradun, Uttarakhand",
              link: "https://www.prosperitytravels.in/",
              impact:
                "Improved website performance by 30% through code optimization and best practices.",
            },
            {
              company: "Expansion JS",
              role: "Software Engineer",
              period: "Feb 2024 - July 2024",
              location: "Texas, United States (Remote)",
              link: "https://www.expansionjs.com/",
              impact:
                "Contributed to the development of scalable applications using modern frameworks.",
            },
            {
              company: "BIZ4SOLUTIONS",
              role: "Programmer",
              period: "Jan 2023 - Dec 2023",
              location: "Pune",
              link: "https://www.biz4solutions.com/",
              impact:
                "Collaborated with cross-functional teams to deliver high-quality software solutions.",
            },
            {
              company: "Iris Software",
              role: "React.js Developer",
              period: "Jul 2022 - Feb 2023",
              location: "New Delhi",
              link: "https://www.irissoftware.com/",
              impact:
                "Led front-end development for key projects, enhancing user experience.",
            },
            {
              company: "Codevyasa",
              role: "Software Engineer",
              period: "Dec 2020 - May 2022",
              location: "New Delhi",
              link: "https://codevyasa.com/",
              impact:
                "Implemented new features and optimized existing code for better performance.",
            },
            {
              company: "Pepcoding",
              role: "Software Engineer Intern period: ",
              period: "Mar 2020 - Sep 2020",
              location: "Pitam Pura, New Delhi",
              link: "https://pepcoding.com/",
              impact:
                "Gained hands-on experience in software development and agile methodologies.",
            },
          ].map((job, index) => (
            <motion.div
              key={index}
              className="bg-gradient-to-br from-gray-900 to-gray-800 p-6 rounded-lg shadow-xl border border-purple-900/30 backdrop-blur-sm hover:border-purple-500/50 transition-all"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
              whileHover={{ scale: 1.02 }}
            >
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-xl font-bold text-purple-200">
                  {job.company}
                </h3>
                <a
                  href={job.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-pink-400 hover:text-pink-300 transform hover:scale-110 transition-all"
                >
                  <ExternalLink size={20} />
                </a>
              </div>
              <p className="text-purple-300 mb-2">{job.role}</p>
              <p className="text-sm text-purple-400">{job.period}</p>
              <p className="text-sm text-purple-400">{job.location}</p>
              <p className="text-sm text-purple-300 mb-2">{job.impact}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Skills Section */}
      <section className="container mx-auto px-4 py-16 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-purple-900/20 to-transparent"></div>
        <motion.h2
          className="text-3xl font-bold mb-12 text-center bg-gradient-to-r from-pink-400 to-purple-400 text-transparent bg-clip-text relative"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          Technical Skills
        </motion.h2>
        <motion.div
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 relative"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          {[
            { category: "Programming", skills: "JavaScript, TypeScript" },
            { category: "Frontend", skills: "React.js, Next.js, React Native" },
            { category: "Backend", skills: "Node.js, MongoDB, MySQL" },
            {
              category: "State Management",
              skills: "Redux, Redux Toolkit, React Query",
            },
            {
              category: "Styling",
              skills: "MUI, Bootstrap, Tailwind CSS, Sass",
            },
            { category: "Other", skills: "Git, Blockchain" },
          ].map((skillSet, index) => (
            <motion.div
              key={index}
              className="bg-gradient-to-br from-gray-900 to-gray-800 p-6 rounded-lg border border-purple-900/30 backdrop-blur-sm hover:border-purple-500/50 transition-all"
              initial={{ scale: 0.8 }}
              whileInView={{ scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.05 }}
            >
              <h3 className="text-xl font-bold mb-3 bg-gradient-to-r from-pink-400 to-purple-400 text-transparent bg-clip-text">
                {skillSet.category}
              </h3>
              <p className="text-purple-300">{skillSet.skills}</p>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* Projects Section */}
      <section className="container mx-auto px-4 py-16">
        <motion.h2
          className="text-3xl font-bold mb-12 text-center bg-gradient-to-r from-pink-400 to-purple-400 text-transparent bg-clip-text"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          Featured Projects
        </motion.h2>
        <div className="grid md:grid-cols-2 gap-8">
          {[
            {
              name: "TRAVOPORT.COM",
              description:
                "Led development of multiple flight booking websites and CRMs, handling both manual and automated systems.",
              tech: "Next.js, C++, SQL, Git, Jira",
              link: "https://www.trav ofinder.com",
              features:
                "Key Features: User-friendly interface, real-time data processing, and secure transactions.",
            },
            {
              name: "HDFC BANK App",
              description:
                "Led development of new features and integrated Adobe Analytics for the mobile banking application.",
              tech: "React Native, TypeScript, Node.js",
              link: "#",
              features:
                "Key Features: Enhanced user experience with seamless navigation.",
            },
            {
              name: "CAARY.COM",
              description:
                "Developed dynamic Wizard form for user authentication with MUI components and data preservation.",
              tech: "React.js, Next.js, TypeScript, MUI",
              link: "#",
              features:
                "Key Features: Efficient data handling and user-friendly design.",
            },
            {
              name: "CODEVYASA.COM",
              description:
                "Led front-end UI design and development, participated in daily scrums, and integrated APIs.",
              tech: "React.js, Redux, Tailwind CSS",
              link: "https://codevyasa.com",
              features:
                "Key Features: Responsive design and robust API integration.",
            },
            {
              name: "FASHINZA.COM",
              description:
                "Contributed to dashboard development and implemented UI using SASS with multiple API integrations.",
              tech: "React.js, TypeScript, SASS, Node.js",
              link: "https://fashinza.com",
              features:
                "Key Features: Real-time data visualization and analytics.",
            },
            {
              name: "DAILYDOC.COM",
              description:
                "Developed multi-step Wizard form for authentication with data preservation across steps.",
              tech: "React.js, SASS, Redux, Node.js",
              link: "#",
              features:
                "Key Features: Streamlined user authentication process.",
            },
          ].map((project, index) => (
            <motion.div
              key={index}
              className="bg-gradient-to-br from-gray-900 to-gray-800 p-6 rounded-lg shadow-xl border border-purple-900/30 backdrop-blur-sm hover:border-purple-500/50 transition-all"
              initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
              whileHover={{ scale: 1.02 }}
            >
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-xl font-bold text-purple-200">
                  {project.name}
                </h3>
                {project.link !== "#" && (
                  <a
                    href={project.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-pink-400 hover:text-pink-300 transform hover:scale-110 transition-all"
                  >
                    <ExternalLink size={20} />
                  </a>
                )}
              </div>
              <p className="text-purple-300 mb-4">{project.description}</p>
              <p className="text-sm text-pink-400">{project.tech}</p>
              <p className="text-sm text-purple-300">{project.features}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 mt-16 relative">
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
        <div className="container mx-auto px-4 text-center text-purple-300 relative">
          <p>© 2024 Nitin Negi. All rights reserved.</p>
          {/* <form className="mt-4">
            <input type="email" placeholder="Subscribe for updates" className="p-2 rounded-l" />
            <button type="submit" className="bg-pink-500 text-white p-2 rounded-r">Subscribe</button>
          </form> */}
        </div>
      </footer>
    </div>
  );
}

export default App;
